# @pixi/core

## Installation

```bash
npm install @pixi/core
```

## Usage

```js
import * as core from '@pixi/core';
```